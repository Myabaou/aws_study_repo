import {Donuts} from "./Donuts";

const myDonuts = new Donuts("オールドファッション", 120, 3);
myDonuts.showOrder();
