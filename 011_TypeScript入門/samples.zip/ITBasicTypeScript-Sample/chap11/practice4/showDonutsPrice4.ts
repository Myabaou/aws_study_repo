import Do from "./Donuts4";

const myDonuts = new Do("オールドファッション", 120, 3);
myDonuts.showOrder();
