export{}

const list: number[] = [3, 7, 11, 16, 19];

console.log(`1コ目: ${list[0]}`);
console.log(`2コ目: ${list[1]}`);
console.log(`3コ目: ${list[2]}`);
console.log(`4コ目: ${list[3]}`);
console.log(`5コ目: ${list[4]}`);
