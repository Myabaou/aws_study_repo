export{}

const myName = "齊藤新三";
console.log(`私の名前は${myName}です。`);
