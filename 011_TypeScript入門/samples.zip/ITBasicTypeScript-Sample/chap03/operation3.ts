export{}

const num1 = 10;
const num2 = 3;

let ans = num1 % num2;
console.log(`num1は${num1}`);
console.log(`num2は${num2}`);
console.log(`num1÷num2のあまりansは${ans}`);
ans++;
console.log(`さらに1足すと${ans}`);
