export{}

let num = 150;
num = num + 5;
console.log(`numの値: ${num}`);
num += 10;
console.log(`numの値: ${num}`);
