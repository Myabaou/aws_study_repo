import {Greetings as Greet} from "../module1/Greetings";

const taro = new Greet("江口太郎");
taro.sayHello();
