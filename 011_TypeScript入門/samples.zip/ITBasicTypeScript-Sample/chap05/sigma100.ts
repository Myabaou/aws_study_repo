export{}

let ans = 0;
let i = 1;
while(i <= 100) {
	ans += i;
	i++;
}
console.log(`結果: ${ans}`);
console.log(`ループ終了後のi: ${i}`);
