export{}

let num = 50;
num++;
console.log(`numの値: ${num}`);
num--;
console.log(`numの値: ${num}`);
