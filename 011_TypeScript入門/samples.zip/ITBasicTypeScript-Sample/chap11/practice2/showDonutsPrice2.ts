import {Donuts, showOrder} from "./Donuts2";

const myDonuts: Donuts =
{
	name: "チョコファッション",
	price: 140,
	quantity: 2
}

showOrder(myDonuts);
