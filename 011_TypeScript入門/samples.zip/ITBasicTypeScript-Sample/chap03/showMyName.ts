export{}

const myName = "齊藤新三";
console.log(myName);
