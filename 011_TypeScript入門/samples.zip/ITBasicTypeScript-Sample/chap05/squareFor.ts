export{}

for(let i = 1; i <= 10; i++) {
	const ans = i ** 2;
	console.log(`${i}回目の結果: ${ans}`);
}
