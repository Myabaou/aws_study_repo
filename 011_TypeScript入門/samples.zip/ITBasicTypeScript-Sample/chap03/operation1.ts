export{}

const num1 = 500;
const num2 = 50;
const ans = num1 / num2;

console.log(`num1は${num1}`);
console.log(`num2は${num2}`);
console.log(`計算結果ansは${ans}`);
