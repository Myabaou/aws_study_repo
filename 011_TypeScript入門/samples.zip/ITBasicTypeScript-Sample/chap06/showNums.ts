export{}

const nums: number[] = [15, 36, 21, 48, 64, 59, 7];
for(let i = 0; i < nums.length; i++) {
	console.log(`${i + 1}番目の値: ${nums[i]}`);
}
