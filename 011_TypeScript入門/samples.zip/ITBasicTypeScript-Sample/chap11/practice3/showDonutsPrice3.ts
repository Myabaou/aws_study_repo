import * as donuts from "../practice2/Donuts2";

const myDonuts: donuts.Donuts =
{
	name: "チョコファッション",
	price: 140,
	quantity: 2
}

donuts.showOrder(myDonuts);
