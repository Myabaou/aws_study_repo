export{}

console.log("123");
console.log(456);
