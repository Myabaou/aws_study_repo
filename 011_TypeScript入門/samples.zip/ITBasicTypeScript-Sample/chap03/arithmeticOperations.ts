export{}

const num1 = 111;
const num2 = 10;

const ans1 = num1 + num2;
const ans2 = num1 - num2;
const ans3 = num1 * num2;
const ans4 = num1 / num2;
const ans5 = num1 % num2;
const ans6 = num1 ** num2;

console.log(ans1);
console.log(ans2);
console.log(ans3);
console.log(ans4);
console.log(ans5);
console.log(ans6);
