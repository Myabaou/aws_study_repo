export{}

const num1 = 3;
const num2 = 7;
const num3 = 11;
const num4 = 16;
const num5 = 19;

console.log(`num1: ${num1}`);
console.log(`num2: ${num2}`);
console.log(`num3: ${num3}`);
console.log(`num4: ${num4}`);
console.log(`num5: ${num5}`);
