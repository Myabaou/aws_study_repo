export{}

let num1 = 10;
console.log(`num1は${num1}です。`);
num1 *= 5;
console.log(`num1を5倍すると${num1}です。`);
