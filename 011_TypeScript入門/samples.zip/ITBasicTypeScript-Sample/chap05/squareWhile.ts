export{}

let i = 1;
while(i <= 10) {
	const ans = i ** 2;
	console.log(`${i}回目の結果: ${ans}`);
	i++;
}
