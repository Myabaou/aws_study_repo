export {}

const label = "お名前: ";
const name = "しんちゃん";

const joinedStr = label + name;
console.log(joinedStr);
