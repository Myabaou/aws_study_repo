export {}

const name = "しんちゃん";
const nameOutput = `あなたのお名前は、${name}です。`;

console.log(nameOutput);
