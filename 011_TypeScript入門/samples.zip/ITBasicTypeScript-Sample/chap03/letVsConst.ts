export{}

let num1 = 56;
const num2 = 35;
console.log(num1);
console.log(num2);
num1 = 28;
// num2 = 18;
console.log(num1);
console.log(num2);
