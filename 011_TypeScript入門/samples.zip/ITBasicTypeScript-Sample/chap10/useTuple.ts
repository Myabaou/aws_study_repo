export{}

const personalData: [string, number, number] = ["太郎", 167.5, 65.1];
for(const element of personalData) {
	console.log(element);
}
// personalData[0] = 456;
// personalData[1] = "こんにちは";
// personalData[3] = 445;

// personalData.shift();
// personalData[0].substring(0);
