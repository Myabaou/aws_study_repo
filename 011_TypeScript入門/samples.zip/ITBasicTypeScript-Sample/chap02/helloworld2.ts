console.log("Hello World!");
console.log("こんにちは!");
