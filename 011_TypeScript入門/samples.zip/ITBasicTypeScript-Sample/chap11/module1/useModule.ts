import {Greetings} from "./Greetings";

const taro = new Greetings("江口太郎");
taro.sayHello();
