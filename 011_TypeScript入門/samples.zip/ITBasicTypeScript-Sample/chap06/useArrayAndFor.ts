export{}

const list: number[] = [3, 7, 11, 16, 19];

for(let i = 0; i <= 4; i++) {
	console.log(`${i + 1}コ目: ${list[i]}`);
}
