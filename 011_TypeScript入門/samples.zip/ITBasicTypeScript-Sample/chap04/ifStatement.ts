export{}

const num = 70;
if(num > 50) {
	console.log("50より大きい");
}
console.log("処理終了");
