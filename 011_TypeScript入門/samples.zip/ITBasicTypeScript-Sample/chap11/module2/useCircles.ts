import {PI, calcAreaOfCircle} from "./Circles";

const radius = 5;
const ans = calcAreaOfCircle(radius, PI);
console.log(`計算された結果: ${ans}`);
