export{}

let sum = 0;
for(let i = 1; i <= 10; i++) {
	sum += i ** 2;
}
console.log(`合計値: ${sum}`);
