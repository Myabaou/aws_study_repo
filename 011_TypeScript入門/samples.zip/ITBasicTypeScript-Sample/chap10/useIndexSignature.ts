export{}

interface NumberIndexed {
	[key: number]: string;
}

const nameList: NumberIndexed =
{
	456: "田中",
	551: "鳳来",
	// name: "名前",
	// "house": "家庭"
}
