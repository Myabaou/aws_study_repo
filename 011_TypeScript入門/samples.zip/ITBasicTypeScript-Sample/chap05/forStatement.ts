export{}

let ans = 0;
for(let i = 1; i <= 100; i++) {
	ans += i;
}
console.log(`結果: ${ans}`);
// console.log(`ループ終了後のi: ${i}`);
