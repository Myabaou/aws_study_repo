export{}

let hisName: string = "田中";
// let hisName = "田中";
console.log(hisName);
hisName = "中野";
console.log(hisName);
// hisName = 789;
