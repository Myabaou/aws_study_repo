import * as circles from "../module2/Circles";

const radius = 5;
const ans = circles.calcAreaOfCircle(radius, circles.PI);
console.log(`計算された結果: ${ans}`);
