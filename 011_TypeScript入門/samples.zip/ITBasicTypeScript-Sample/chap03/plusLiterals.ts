export{}

const ans = 712 + 442;
console.log(ans);
