export{}

const list: number[] = [3, 7, 11, 16, 19];

for(const element of list) {
	console.log(element);
}
